$(function ($) {
    /*$('.auth .login').click(function () {
        $('.login-pop').removeAttr('style')
    })
    $('.login-pop .fas').click(function () {
        $('.login-pop').css('display','none')

    })*/
});

/*
function changePanda(url) {
    if(url) {
        $('.panda-img img').attr('src',url);
    }else {
        $('.panda-img img').attr('src','https://b-gold-cdn.xitu.io/v3/static/img/normal.0447fe9.png');
    }
}*/

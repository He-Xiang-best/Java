package cc.test.vo;

public class Book {
	private String bookId;	//���
	private String bookName;//����
	String bookImg;			//��������ڵ�ַ
	private int bookNum;	//���鱾��

	public Book(String bookId, String bookName, String bookImg, int bookNum) {
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookImg = bookImg;
		this.bookNum = 0;
	}

	public String getBookId() {
		return bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public String getBookImg() {
		return bookImg;
	}

	public int getBookNum() {
		return bookNum;
	}

}
